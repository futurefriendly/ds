
var DidiMonitor = require('didimonitor');
var DidiBridge = require('didibridge');
var _page = DidiMonitor.getQuery('page');

if(_page != ''){
	$('#'+_page).css('display','block');
}